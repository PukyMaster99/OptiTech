export default function AdminDashboard(){
  return (
    <main style={{ maxWidth: 800, margin:'24px auto', padding:16 }}>
      <h2>Administrador</h2>
      <p>MVP: aquí luego crearás perfiles y vínculos. Por ahora no hace falta.</p>
    </main>
  );
}
